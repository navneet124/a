package com.cognizant.ems.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	public static final String URL="jdbc:mysql://localhost:3306/test?useSSL=false";
	public static final String CLASS_NAME="com.mysql.jdbc.Driver";
	public static final String USERNAME="root";
	public static final String PASSWORD="root";
	
	public static Connection getConnection()
	{
		Connection connection=null;
		try
		{
			Class.forName(CLASS_NAME);
			connection=DriverManager.getConnection(URL,USERNAME,PASSWORD);
		}
		catch(ClassNotFoundException classNotFoundException)
		{
			classNotFoundException.printStackTrace();
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}
		return connection;
		
	}
	public static void closeConnection(Connection connection)
	{
		try{
			connection.close();
		}
		catch(Exception exception)
		{
			System.out.println(exception);
		}
	}
}
