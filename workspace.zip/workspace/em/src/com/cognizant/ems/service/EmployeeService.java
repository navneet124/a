package com.cognizant.ems.service;

import com.cognizant.ems.bean.EmployeeBean;

public interface EmployeeService {

	public String insertEmployee(EmployeeBean employeeBean);
	public EmployeeBean getEmployeeDetail(String employeeId);
}
