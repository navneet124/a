package com.cognizant.ems.service;

import com.cognizant.ems.bean.EmployeeBean;
import com.cognizant.ems.dao.EmployeeDAO;
import com.cognizant.ems.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDAO employeeDAO =new EmployeeDAOImpl();
	@Override
	public String insertEmployee(EmployeeBean employeeBean) {
		// TODO Auto-generated method stub
		return employeeDAO.insertEmployee(employeeBean);
	}

	@Override
	public EmployeeBean getEmployeeDetail(String employeeId) {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployeeDetail(employeeId);
	}

}
