package com.cognizant.ems.service;

import com.cognizant.ems.bean.LoginBean;
import com.cognizant.ems.dao.LoginDAO;
import com.cognizant.ems.dao.LoginDAOImpl;

public class LoginServiceImpl implements LoginService {

	LoginDAO loginDAO=new LoginDAOImpl();
	@Override
	public String insertLogin(LoginBean loginBean) {
		// TODO Auto-generated method stub
		return loginDAO.insertLogin(loginBean);
	}

	@Override
	public boolean authenticateUser(LoginBean loginBean) {
		// TODO Auto-generated method stub
		return loginDAO.authenticateUser(loginBean);
	}

}
