package com.cognizant.ems.service;

import com.cognizant.ems.bean.LoginBean;

public interface LoginService {

	public String insertLogin(LoginBean loginBean);
	public boolean authenticateUser(LoginBean loginBean);
}
