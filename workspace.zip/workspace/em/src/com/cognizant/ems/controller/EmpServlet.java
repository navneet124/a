package com.cognizant.ems.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.ems.bean.EmployeeBean;
import com.cognizant.ems.service.EmployeeService;
import com.cognizant.ems.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmpServlet
 */
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");
		 String empId=request.getParameter("empId");
		 EmployeeBean employeeBean=new EmployeeBean();
		 EmployeeService employeeService=new EmployeeServiceImpl();
		 employeeBean=employeeService.getEmployeeDetail(empId);
		 System.out.println(employeeBean);
		  //response.sendRedirect("register.html");
		//RequestDispatcher rd = request.getRequestDispatcher("empDetails.html");
		//rd.forward(request, response);
	}

}
