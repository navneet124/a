package com.cognizant.ems.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.ems.bean.EmployeeBean;
import com.cognizant.ems.service.EmployeeService;
import com.cognizant.ems.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeRegisterServlet
 */
public class EmployeeRegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeRegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void dispatcher(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String employeeId=request.getParameter("employeeId");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		int salary=Integer.parseInt(request.getParameter("salary"));
		String designation=request.getParameter("designation");
		String password=request.getParameter("password");
		
		EmployeeBean employeeBean=new EmployeeBean();
		employeeBean.setEmpId(employeeId);
		employeeBean.setFirstName(firstName);
		employeeBean.setLastName(lastName);
		employeeBean.setSalary(salary);
		employeeBean.setDesignation(designation);
		employeeBean.setPassword(password);
		//System.out.println(employeeBean);
		EmployeeService employeeService=new EmployeeServiceImpl();
		
		if(employeeService.insertEmployee(employeeBean).equalsIgnoreCase("success"))
		{
			System.out.println("Insertion successful");
			//RequestDispatcher rd=request.getRequestDispatcher("employeeId.html");
			//rd.include(request,response);
		}
		else
		{
			
			System.out.println("Insertion unsuccessful");
		}
		
		
	}

}
