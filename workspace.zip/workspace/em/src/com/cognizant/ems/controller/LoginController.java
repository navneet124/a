package com.cognizant.ems.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.ems.bean.LoginBean;
import com.cognizant.ems.service.LoginService;
import com.cognizant.ems.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void dispatcher(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName=request.getParameter("userNane");
		String userPass=request.getParameter("userPass");
		
		/*if("admin".equals(userName)&&"admin".equals(userPass))
		{
			System.out.println("valid");
		}
		else
		{
			System.out.println("invalid");
		}*/
		LoginBean loginBean=new LoginBean();
		loginBean.setUserName(userName);
		loginBean.setPassword(userPass);
		LoginService loginService=new LoginServiceImpl();
		if(loginService.authenticateUser(loginBean))
		{
			System.out.println("login successful");
		}
		else
		{
			System.out.println("login unsuccessful");
		}
		
		
	}

}
