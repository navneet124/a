package com.cognizant.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.ems.bean.EmployeeBean;
import com.cognizant.ems.util.DBUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	String insertQuery=null;
	@Override
	public String insertEmployee(EmployeeBean employeeBean) {
		// TODO Auto-generated method stub
		//System.out.println(employeeBean);
		insertQuery="insert into employee (emp_id, first_name, last_name, sal, degn, password) values(?,?,?,?,?,?)";
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		connection=DBUtil.getConnection();
		try {
			preparedStatement=connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, employeeBean.getEmpId());
			preparedStatement.setString(2, employeeBean.getFirstName());
			preparedStatement.setString(3, employeeBean.getLastName());
			preparedStatement.setInt(4, employeeBean.getSalary());
			preparedStatement.setString(5, employeeBean.getDesignation());
			preparedStatement.setString(6, employeeBean.getPassword());
			preparedStatement.executeUpdate();
			return "success";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "failed";
		}
		finally{
			DBUtil.closeConnection(connection);
		}
		
	}

	@Override
	public EmployeeBean getEmployeeDetail(String employeeId) {
		// TODO Auto-generated method stub
		insertQuery="select * from employee where emp_id=?";
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		connection=DBUtil.getConnection();
		ResultSet resultSet=null;
		try {
			preparedStatement=connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, employeeId);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				EmployeeBean employeeBean=new EmployeeBean();
				//employeeBean=
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}



}
