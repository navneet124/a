package com.cognizant.ems.dao;

import com.cognizant.ems.bean.LoginBean;

public interface LoginDAO {

	public String insertLogin(LoginBean loginBean);
	public boolean authenticateUser(LoginBean loginBean);
	public LoginBean getLoginDetail(LoginBean loginBean);
	
	
}
