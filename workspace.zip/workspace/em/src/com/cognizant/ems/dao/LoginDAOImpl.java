package com.cognizant.ems.dao;

import com.cognizant.ems.bean.LoginBean;
import com.cognizant.ems.util.DBUtil;
import java.sql.*;

public class LoginDAOImpl implements LoginDAO {

	String insertQuery;
	@Override
	public String insertLogin(LoginBean loginBean) {
		// TODO Auto-generated method stub
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		connection=DBUtil.getConnection();
		insertQuery="insert into login (emp_id,password) values(?,?)";
		try {
			preparedStatement=connection.prepareStatement(insertQuery);
			
			preparedStatement.setString(1, loginBean.getUserName());
			preparedStatement.setString(2, loginBean.getPassword());
		    preparedStatement.executeUpdate();
			connection.commit();
			return "success";
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return "failed";
		}
		finally{
			DBUtil.closeConnection(connection);
		}
	}

	@Override
	public LoginBean getLoginDetail(LoginBean loginBean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean authenticateUser(LoginBean loginBean) {
		// TODO Auto-generated method stub
		insertQuery="select * from login where emp_id=? and password=?";
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		connection=DBUtil.getConnection();
		ResultSet resultSet=null;
		try {
			preparedStatement=connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, loginBean.getUserName());
			preparedStatement.setString(2, loginBean.getPassword());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				return true;
			}
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}

}
