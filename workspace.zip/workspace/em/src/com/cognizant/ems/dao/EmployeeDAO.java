package com.cognizant.ems.dao;

import com.cognizant.ems.bean.EmployeeBean;

public interface EmployeeDAO {

	public String insertEmployee(EmployeeBean employeeBean);
	public EmployeeBean getEmployeeDetail(String employeeId);
}
