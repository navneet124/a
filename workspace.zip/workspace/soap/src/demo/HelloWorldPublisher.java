package demo;

import javax.xml.ws.Endpoint;

public class HelloWorldPublisher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("About to publish");
		Endpoint.publish("http://127.0.0.1:9876/hw?wsdl", new HelloWorldServerImpl());
		System.out.println("service published...");
	}

}
