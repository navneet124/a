package demo;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class HelloWorldClient {
	public static void main(String[] args) {
	try{
	URL url=new URL("http://127.0.0.1:9876/hw?wsdl");
	QName qname=new QName("http://demo/","HelloWorldServerImplService");
	Service service=Service.create(url,qname);
	HelloWorldServer server=service.getPort(HelloWorldServer.class);
	System.out.println(server.sayHello("navneet"));
	}
	catch(MalformedURLException e){
		e.printStackTrace();
	}
}
}
