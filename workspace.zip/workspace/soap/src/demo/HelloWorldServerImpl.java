package demo;

import javax.jws.WebService;

@WebService(endpointInterface="demo.HelloWorldServer")
public class HelloWorldServerImpl implements HelloWorldServer{

	public String sayHello(String name) {
		return "Hello"+ name +"!,Hope you are doing well !!";
	}

	
	
}
