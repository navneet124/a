package com.cognizant.employeemanegmentsystem.bean;

public class EmployeeBean {
private String userName;
private String empFirstName;
private String empLastName;
private String password;
private int salary;
public EmployeeBean() {
	super();
}
public EmployeeBean(String userName, String empFirstName, String empLastName, String password, int salary) {
	super();
	this.userName = userName;
	this.empFirstName = empFirstName;
	this.empLastName = empLastName;
	this.password = password;
	this.salary = salary;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getEmpFirstName() {
	return empFirstName;
}
public void setEmpFirstName(String empFirstName) {
	this.empFirstName = empFirstName;
}
public String getEmpLastName() {
	return empLastName;
}
public void setEmpLastName(String empLastName) {
	this.empLastName = empLastName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((empFirstName == null) ? 0 : empFirstName.hashCode());
	result = prime * result + ((empLastName == null) ? 0 : empLastName.hashCode());
	result = prime * result + ((password == null) ? 0 : password.hashCode());
	result = prime * result + salary;
	result = prime * result + ((userName == null) ? 0 : userName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	EmployeeBean other = (EmployeeBean) obj;
	if (empFirstName == null) {
		if (other.empFirstName != null)
			return false;
	} else if (!empFirstName.equals(other.empFirstName))
		return false;
	if (empLastName == null) {
		if (other.empLastName != null)
			return false;
	} else if (!empLastName.equals(other.empLastName))
		return false;
	if (password == null) {
		if (other.password != null)
			return false;
	} else if (!password.equals(other.password))
		return false;
	if (salary != other.salary)
		return false;
	if (userName == null) {
		if (other.userName != null)
			return false;
	} else if (!userName.equals(other.userName))
		return false;
	return true;
}
@Override
public String toString() {
	return "Employee \nuserName=" + userName + "\n FirstName=" + empFirstName + "\n LastName=" + empLastName
			+ "\n password=" + password + "\n salary=" + salary;
}


}
