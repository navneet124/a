package com.cognizant.employeemanegmentsystem.service;

import com.cognizant.employeemanegmentsystem.bean.LoginBean;
import com.cognizant.employeemanegmentsystem.dao.LoginDAO;
import com.cognizant.employeemanegmentsystem.dao.LoginDAOImpl;

public class LoginServiceImpl implements LoginService {
	

	@Override
	public String insertLogin(LoginBean loginBean) {
		LoginDAO loginDao = new LoginDAOImpl();
		
		return loginDao.insertLogin(loginBean);
	}

	@Override
	public boolean authenticate(LoginBean loginBean) {
		LoginDAO loginDao = new LoginDAOImpl();
		
		return loginDao.authenticate(loginBean);
	}

}
