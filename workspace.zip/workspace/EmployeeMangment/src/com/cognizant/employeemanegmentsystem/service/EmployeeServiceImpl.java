package com.cognizant.employeemanegmentsystem.service;

import com.cognizant.employeemanegmentsystem.bean.EmployeeBean;
import com.cognizant.employeemanegmentsystem.dao.EmployeeDAO;
import com.cognizant.employeemanegmentsystem.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public boolean insertEmployee(EmployeeBean employee) {
		EmployeeDAO eDao = new EmployeeDAOImpl();
		return eDao.insertEmployee(employee);
	}

	@Override
	public EmployeeBean getEmployeeDetail(String userName) {
		EmployeeDAO eDao = new EmployeeDAOImpl();
		return eDao.getEmployeeDetail(userName);
	}

}
