package com.cognizant.employeemanegmentsystem.service;

import com.cognizant.employeemanegmentsystem.bean.LoginBean;

public interface LoginService {
	public String insertLogin(LoginBean loginBean);
	//public LoginBean getLoginDetail(LoginBean loginBean);
	public boolean authenticate(LoginBean loginBean);
}
