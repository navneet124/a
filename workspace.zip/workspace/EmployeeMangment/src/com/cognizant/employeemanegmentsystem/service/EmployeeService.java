package com.cognizant.employeemanegmentsystem.service;

import com.cognizant.employeemanegmentsystem.bean.EmployeeBean;

public interface EmployeeService {

	public boolean insertEmployee(EmployeeBean employee);
	public EmployeeBean getEmployeeDetail(String userName);
	
}
