package com.cognizant.employeemanegmentsystem.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.employeemanegmentsystem.bean.EmployeeBean;
import com.cognizant.employeemanegmentsystem.service.EmployeeService;
import com.cognizant.employeemanegmentsystem.service.EmployeeServiceImpl;

/**
 * Servlet implementation class EmployeeSearchServlet
 */
public class DisplayController {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void dispatcher(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		String userName = request.getParameter("userName");
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		EmployeeBean bean = new EmployeeBean();
		bean = employeeService.getEmployeeDetail(userName);
			//System.out.println(bean);
			out.print(bean);
	}

}
