package com.cognizant.employeemanegmentsystem.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.log.Log;

/**
 * Servlet implementation class FrontController
 */
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String query = request.getQueryString();
		System.out.println(query);
		if("login".equals(query)){
			LoginController controller = new LoginController();
			controller.dispatcher(request, response);
		}
		else if("register".equals(query))
		{
			RegisterController controller = new RegisterController();
			controller.dispatcher(request, response);
		}
		else if ("search".equals(query)) {
			DisplayController controller = new DisplayController();
			controller.dispatcher(request, response);
		}
	}

}
