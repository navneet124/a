package com.cognizant.employeemanegmentsystem.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.employeemanegmentsystem.bean.EmployeeBean;
import com.cognizant.employeemanegmentsystem.bean.LoginBean;
import com.cognizant.employeemanegmentsystem.dao.EmployeeDAO;
import com.cognizant.employeemanegmentsystem.dao.EmployeeDAOImpl;
import com.cognizant.employeemanegmentsystem.service.EmployeeService;
import com.cognizant.employeemanegmentsystem.service.EmployeeServiceImpl;
import com.cognizant.employeemanegmentsystem.service.LoginService;
import com.cognizant.employeemanegmentsystem.service.LoginServiceImpl;

/**
 * Servlet implementation class EmployeeRegisterServlet
 */
public class RegisterController  {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void dispatcher(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String empFirstName = request.getParameter("fName");
		String empLastName = request.getParameter("lName");
		String password = request.getParameter("password");
		int salary = Integer.parseInt(request.getParameter("salary")); 
		
		LoginBean loginBean = new LoginBean();
		loginBean.setUserName(userName);
		loginBean.setPassword(password);
		LoginService loginService = new LoginServiceImpl();
		loginService.insertLogin(loginBean);
		
		EmployeeBean employeeBean = new EmployeeBean();
		employeeBean.setUserName(userName);
		employeeBean.setEmpFirstName(empFirstName);
		employeeBean.setEmpLastName(empLastName);
		employeeBean.setPassword(password);
		employeeBean.setSalary(salary);
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		if(employeeService.insertEmployee(employeeBean)){
			System.out.println("Data Inserted");
		}
		else{
			System.out.println("Not inserted");
		}
		
		
		
	}

}
