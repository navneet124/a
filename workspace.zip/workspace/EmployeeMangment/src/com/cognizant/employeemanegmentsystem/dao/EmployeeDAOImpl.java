package com.cognizant.employeemanegmentsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cognizant.employeemanegmentsystem.bean.EmployeeBean;
import com.cognizant.employeemanegmentsystem.util.DBUtils;

public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public boolean insertEmployee(EmployeeBean employee) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = DBUtils.getConnection();
		String insertQuery = "insert into employee_table (userName , empFirstName , empLastName, password ,salary) values(?, ?, ?, ?, ?) ";
		try {
			preparedStatement= connection.prepareStatement(insertQuery);
			preparedStatement.setString(1, employee.getUserName());
			preparedStatement.setString(2, employee.getEmpFirstName());
			preparedStatement.setString(3, employee.getEmpLastName());
			preparedStatement.setString(4, employee.getPassword());
			preparedStatement.setInt(5, employee.getSalary());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			try {
				connection.rollback();
				return false;
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}finally {
			DBUtils.closeConnection(connection);;
		}
		return true;
		
	}

	@Override
	public EmployeeBean getEmployeeDetail(String userName) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		connection = DBUtils.getConnection();
		String query = "select *from employee_table where username= ?";
		ResultSet resultSet = null;
		EmployeeBean bean = new EmployeeBean();
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, userName);
			resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				bean.setUserName(resultSet.getString(1));
				bean.setEmpFirstName(resultSet.getString(2));
				bean.setEmpLastName(resultSet.getString(3));
				bean.setPassword(resultSet.getString(4));
				bean.setSalary(resultSet.getInt(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bean;
	}

	

}
