package com.cognizant.employeemanegmentsystem.dao;

import com.cognizant.employeemanegmentsystem.bean.LoginBean;

public interface LoginDAO {
public String insertLogin(LoginBean loginBean);
//public LoginBean getLoginDetail(LoginBean loginBean);
public boolean authenticate(LoginBean loginBean);
}
