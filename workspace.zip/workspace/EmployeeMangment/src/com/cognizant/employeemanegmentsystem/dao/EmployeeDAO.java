package com.cognizant.employeemanegmentsystem.dao;

import com.cognizant.employeemanegmentsystem.bean.EmployeeBean;
import com.cognizant.employeemanegmentsystem.bean.LoginBean;

public interface EmployeeDAO {

	public boolean insertEmployee(EmployeeBean employee);
	public EmployeeBean getEmployeeDetail(String userName);
	
}
