package model;
import java.sql.*;
public class MyConnection {
	private static String driver="oracle.jdbc.driver.OracleDriver";
	private static String url="jdbc:oracle:thin:@localhost:1521:xe";
	private MyConnection(){}
	private static MyConnection mc=new MyConnection();
	
	public static MyConnection getObj()
	{
		return mc;
	}
	public static Connection crtCon() throws Exception
	{
		Class.forName(driver);
		Connection con=DriverManager.getConnection(url,"hr","hr");
		return con;
	}
}
