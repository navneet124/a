package model;

import java.sql.*;

public class DAOImpl implements DAO{
	public int insert(String query) throws Exception
	{
		MyConnection.getObj();
		Connection con=MyConnection.crtCon();
		Statement st=con.createStatement();
		int i=st.executeUpdate(query);
		return i;
	}
	public int update(String query) throws Exception
	{
		Connection con=MyConnection.getObj().crtCon();
		Statement st=con.createStatement();
		int i=st.executeUpdate(query);
		return i;
	}
	public int delete(String query) throws Exception
	{
		Connection con=MyConnection.getObj().crtCon();
		Statement st=con.createStatement();
		int i=st.executeUpdate(query);
		return i;
	}
	public ResultSet select(String query) throws Exception
	{
		Connection con=MyConnection.getObj().crtCon();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery(query);
		return rs;
	}
}
