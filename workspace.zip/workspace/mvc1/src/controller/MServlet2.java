package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class MServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public MServlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String unm=request.getParameter("name");
		String pswd=request.getParameter("pswd");
		String newpswd=request.getParameter("pswd1");
		Bean2 b2=new Bean2();
		try{
			String a=b2.buildQuery2(unm, pswd, newpswd);
			//response.getWriter().print(a);
			RequestDispatcher rd=request.getRequestDispatcher("view/update.jsp?val="+a);
			rd.include(request,response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
