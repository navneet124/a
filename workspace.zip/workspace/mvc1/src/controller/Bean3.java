package controller;

import model.DAOImpl;

public class Bean3 {
	public String buildQuery1(String id) throws Exception
	{
		DAOImpl daoimpl1=new DAOImpl();
		String query1="delete from usertab where userid='"+id+"'";
		int i=daoimpl1.insert(query1);
		if(i==1)
			return "delete successful";
		else
		
		return "delete unsuccessful";
		
	}
}
