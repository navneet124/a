package controller;

import model.DAOImpl;

public class Bean1 {
	public String buildQuery1(String id, String pswd, String type) throws Exception
	{
		DAOImpl daoimpl1=new DAOImpl();
		String query1="insert into usertab values('"+id+"','"+pswd+"','"+type+"')";
		int i=daoimpl1.insert(query1);
		if(i==1)
			return "successful";
		else
		
		return "unsuccessful";
		
	}
}
