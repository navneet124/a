package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public MServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String unm=request.getParameter("name");
		String pswd=request.getParameter("pswd");
		Bean b=new Bean();
		try
		{
			String output=b.buildQuery(unm, pswd);
			if(output.equals("a"))
			{
				RequestDispatcher rd=request.getRequestDispatcher("view/admin.jsp");
				rd.forward(request,response);
			}
			else if(output.equals("c"))
			{
				RequestDispatcher rd=request.getRequestDispatcher("view/user.jsp");
				rd.forward(request,response);
			}
			else
			{
				response.getWriter().print(output);
				RequestDispatcher rd=request.getRequestDispatcher("view/redirect.jsp?val="+output);
				rd.forward(request,response);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
