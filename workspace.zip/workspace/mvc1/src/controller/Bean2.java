package controller;

import model.DAOImpl;

public class Bean2 {
	public String buildQuery2(String id, String pswd, String newpswd) throws Exception
	{
		DAOImpl daoimpl1=new DAOImpl();
		String query1="update usertab set password='"+newpswd+"' where userid='"+id+"' and password='"+pswd+"'";
		int i=daoimpl1.update(query1);
		if(i==1)
			return "successful";
		else
		
		return "unsuccessful";
		
	}
}
