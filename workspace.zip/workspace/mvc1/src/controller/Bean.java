package controller;

import java.sql.ResultSet;
import model.DAOImpl;

public class Bean {
	public String buildQuery(String id, String pswd) throws Exception
	{
		DAOImpl daoimpl=new DAOImpl();
		String query="select type from usertab where userid='"+id+"' and password='"+pswd+"'";
		ResultSet rs=daoimpl.select(query);
		if(rs.next())
			return rs.getString(1);
		else
			return "invalid credentials";
	}
}
