package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class MServlet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public MServlet3() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String unm=request.getParameter("name");
		Bean3 b2=new Bean3();
		try{
			String a=b2.buildQuery1(unm);
			response.setContentType("text/html");
			response.getWriter().print(a);
			//RequestDispatcher rd=request.getRequestDispatcher("view/delete.jsp?val="+a);
			//rd.include(request,response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
