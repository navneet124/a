package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class MServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public MServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String unm=request.getParameter("name");
		String pswd=request.getParameter("pswd");
		String type=request.getParameter("type");
		Bean1 b1=new Bean1();
		try{
			String a=b1.buildQuery1(unm, pswd, type);
			//response.getWriter().print(a);
			RequestDispatcher rd=request.getRequestDispatcher("view/insert1.jsp?val="+a);
			rd.include(request,response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
