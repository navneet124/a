package com.Sequence.preffix;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

public class Sequnce {
	@Autowired
	PreffixGenrator prefix;
	@Value("sdg")
	String initial;
	@Value("cogni")
	String suffix;
	public Sequnce() {
		super();
	}
	

	public Sequnce(PreffixGenrator prefix, String initial, String suffix) {
		super();
		this.prefix = prefix;
		this.initial = initial;
		this.suffix = suffix;
	}


	public PreffixGenrator getPrefix() {
		return prefix;
	}


	public void setPrefix(PreffixGenrator prefix) {
		this.prefix = prefix;
	}


	public String getInitial() {
		return initial;
	}


	public void setInitial(String initial) {
		this.initial = initial;
	}


	public String getSuffix() {
		return suffix;
	}


	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}


	@Override
	public String toString() {
		return prefix.getPreffix() + initial + suffix ;
	}


	
}
