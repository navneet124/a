package springibpack;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository
@Qualifier("EmployeDAO")
public class EmployeeJdbcDAOImpl implements EmployeeDAO {

	@Autowired
	JdbcTemplate jdbcTemplate;
	@Override
	public void save(Employee employee) {
		// TODO Auto-generated method stub
		jdbcTemplate.update("insert into employee values (?, ?, ?, ?)",employee.getEcode(),employee.getEname(),employee.getDept(),employee.getSalary());
		System.out.println("person added");

	}

	@Override
	public List<Employee> list() {
		// TODO Auto-generated method stub
		List<Employee> elist=jdbcTemplate.query("select * from employee", new BeanPropertyRowMapper<Employee>(Employee.class));
		return elist;
	}

}
