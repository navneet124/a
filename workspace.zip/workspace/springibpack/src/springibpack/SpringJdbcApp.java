package springibpack;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringJdbcApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new AnnotationConfigApplicationContext(AnnotConfig.class);
		EmployeeDAO service=context.getBean(EmployeeJdbcDAOImpl.class);
		Employee employee=new Employee(200, "priyanka", "hr", 120000);
		service.save(employee);
		
		System.out.println("display All");
		List<Employee> elist=service.list();
		
		for(Employee emp: elist){
			System.out.println(emp);
		}
	}

}
