package springibpack;

import java.util.List;

public interface EmployeeDAO {

	public void save(Employee employee);
	public List<Employee> list();
}
