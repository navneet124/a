package aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class Audience {
	
	@Before("perform()")
	public void takeSeats(){
		System.out.println("the audience is taking seats.");
	}
}
