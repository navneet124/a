package aspect;

public class AnnotAOP {

}
