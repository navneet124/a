package aspect;

import org.aspectj.lang.annotation.Pointcut;

public class Performance {

	@Pointcut("aspect.Audience.takeSeats()")
	public void perform()
	{
		
	}
}
