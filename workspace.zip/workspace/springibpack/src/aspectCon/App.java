package aspectCon;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("spring-customer.xml");
		CustomerService cust=(CustomerService) context.getBean("customerServiceProxy");
		System.out.println(cust.getName());
		System.out.println(cust.getUrl());
		try{
		cust.printThrowException();
		}
		catch(Exception e){
			System.out.println(e +" error");
		}
	}

}
