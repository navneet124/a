package sprhibernate;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public void save(Employee employee) {
		// TODO Auto-generated method stub

		Session session = this.sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.persist(employee);
		tx.commit();
		session.close();
	}

	@Override
	public List<Employee> list() {
		// TODO Auto-generated method stub
		Session session = this.sessionFactory.openSession();
		List<Employee> empList=session.createQuery("from employee");
		session.close();
		return empList;
	}

}
