package sprhibernate;

import java.util.List;

public interface EmployeeDao {

	public void save(Employee employee);
	public List<Employee> list();
}
