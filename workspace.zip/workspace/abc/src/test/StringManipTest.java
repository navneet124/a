package test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class StringManipTest {

	private String actual ;
	private String expected;
	
	public StringManipTest(String actual, String expected) {
		super();
		this.actual = actual;
		this.expected = expected;
	}
	@Parameters
	public static Collection <Object []> generateData(){
	
		Object [][] strdata={
				{"smita","SMITA"},
				{"navneet","NAVNEET"},
				{"mrinal","MRINAL"},
				{"vishal","VISHAL"},
				{"shantanu","SHANTANU"},
				{"ankit","ANKIT"}
		};
		return Arrays.asList(strdata);
	}
	@Test
	public void testUpperCase(){
		Stringmanip2 sm=new Stringmanip2(this.actual);
		
		assertEquals(sm.upperCase(),this.expected);
	}
	
}
