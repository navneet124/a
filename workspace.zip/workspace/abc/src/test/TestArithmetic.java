package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestArithmetic {

	@Before
	public void setUp() throws Exception {
		System.out.println("befor test start");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("test over");
	}

	@Test
	public void testIsPositive() {
		Arithmetic arithmetic=new Arithmetic();
		assertEquals(true, arithmetic.isPositive(10));
	}
	
	@Test
	public void testMultiply() {
		Arithmetic arithmetic=new Arithmetic();
		assertEquals(200, arithmetic.multiply(10, 20));
	}
	
	@Test
	public void testGetMax() {
		Arithmetic arithmetic=new Arithmetic();
		assertEquals(20, arithmetic.getMax(10, 20));
	}

}
