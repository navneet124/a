package test;

public class Arithmetic {

	public boolean isPositive(int a)
	{
		if(a>0)
			return true;
		else
			return false;
	}
	public int multiply(int n1, int n2)
	{
		return n1*n2;
	}
	public int getMax(int n1, int n2)
	{
		if(n1>n2)
			return n1;
		else
			return n2;
	}
}
