package test;

public class Stringmanip2 {

	private String actual;

	public Stringmanip2() {
		super();
	}
	public Stringmanip2(String actual) {
		super();
		this.actual = actual;
	}
	public String upperCase(){
		return actual.toUpperCase();
	}
}
