package test;

public class Stringmanip {

	private String actual ;
	private String expected;
	
	public Stringmanip() {
		super();
	}
	public Stringmanip(String actual, String expected) {
		super();
		this.actual = actual;
		this.expected = expected;
	}
	public String getActual() {
		return actual;
	}
	public void setActual(String actual) {
		this.actual = actual;
	}
	public String getExpected() {
		return expected;
	}
	public void setExpected(String expected) {
		this.expected = expected;
	}

	
}
