package abc;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestString {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testIsEquals() {
		CheckStrings ck1=new CheckStrings();
		assertEquals(true,ck1.isEquals("abc"));
	}

	@Test
	public final void testCheckNull() {
		CheckStrings ck2=new CheckStrings();
		assertNull(ck2.checkNull(null));
	}
	
	@Test
	public final void testReverseString() {
		CheckStrings ck3=new CheckStrings();
		assertEquals("cba",ck3.reverseString("abc"));
	}
}
