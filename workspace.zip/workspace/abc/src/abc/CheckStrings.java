package abc;

public class CheckStrings {
boolean isEquals(String s1){
	
		String s="abc";
		if(s.equals(s1))
		{
			return true;
		}
		else
			return false;
}	

String checkNull(String s2){
	if(s2==null)
		return null;
	else
		return "not null";
}
String reverseString(String s3)
{
    StringBuilder input1 = new StringBuilder(s3); 
    input1.reverse(); 
    
	return input1.toString();
}
}