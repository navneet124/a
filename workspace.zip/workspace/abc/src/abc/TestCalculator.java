package abc;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestCalculator {

	@Before
	public void setUp() throws Exception {
		System.out.println("befor test start");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("test over");
	}
//these are test methods
	@Test
	public final void testAdd() {
		Calculator c=new Calculator();
		assertEquals(30,c.add(10, 20));
		assertEquals(50,c.add(30, 20));
	}

	@Test
	public final void testSubtract(){
		Calculator c=new Calculator();
		assertEquals(30,c.subtract(60, 30));
	}
	
	@Test
	public final void testMultiply(){
		Calculator c=new Calculator();
		assertEquals(30,c.mulitply(10, 3));
	}
	
	@Test
	public final void testDivide(){
		Calculator c=new Calculator();
		assertEquals(30,c.divide(300, 10));
	}

}
