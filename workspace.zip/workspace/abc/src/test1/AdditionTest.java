package test1;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class AdditionTest {

	private int n1,n2,r;

	public AdditionTest(int r, int n1, int n2) {
		super();
		this.n1 = n1;
		this.n2 = n2;
		this.r=r;
	}
	
	@Parameters
	public static Collection<Object []> calcSum(){
		Object [][] sum={
				{0,0,0},
				{1,1,0},
				{2,1,1},
				{3,2,1},
				{4,3,1},
				{5,5,0},
				{6,8,-2}
		};
		return Arrays.asList(sum);
	}
	
	@Test
	public void testAdd(){
		Addition addition=new Addition(this.n1,this.n2);
		assertEquals(addition.add(),this.r);
	}
	
}
