package test1;

import static org.junit.Assert.*;

import org.junit.Test;

public class BiscuitTest {

	@Test
	public void test() {
		Biscuit b1=new Biscuit("Good Day");
		//assertThat("Good Day",is(equalTo(b1.getA())));
	}

}
