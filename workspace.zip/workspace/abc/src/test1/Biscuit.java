package test1;

public class Biscuit {
private String a;

public String getA() {
	return a;
}

public void setA(String a) {
	this.a = a;
}

public Biscuit() {
	super();
}

public Biscuit(String a) {
	super();
	this.a = a;
}

}
