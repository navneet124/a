package test1;

public class Addition {

	private int n1,n2;
	
	public Addition() {
		super();
	}
	public Addition(int n1, int n2) {
		super();
		this.n1 = n1;
		this.n2 = n2;
	}
	public int add()
	{
		return n1+n2;
	}
}