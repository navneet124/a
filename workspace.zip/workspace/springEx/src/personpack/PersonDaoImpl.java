package personpack;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class PersonDaoImpl implements PersonDao{

	JdbcTemplate jdt;

	public PersonDaoImpl() {
		super();
	}

	public PersonDaoImpl(JdbcTemplate jdt) {
		super();
		this.jdt = jdt;
	}
	
	public int insertObj(Person p)
	{
		Object []param={p.getName(),p.getAddr(),p.getAge()};
		int n=jdt.update("insert into person values(?,?,?)",param);
		return n;
	}

	@Override
	public void showRecord(String pname) {
		// TODO Auto-generated method stub
		Object []param={pname};
		Person p=jdt.queryForObject("select * from person where name=?", param,new PersonRowMapper());
		System.out.println("name :"+p.getName()+"\naddress :"+p.getAddr()+"\nage :"+p.getAge());	
	}
	

	@Override
	public List<Person> displayAll() {
		// TODO Auto-generated method stub
		List<Person> plist=(List<Person>)jdt.query("select * from person", new PersonRowMapper());
		return plist;
	}
}
