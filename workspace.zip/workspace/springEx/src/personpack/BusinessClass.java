package personpack;

import java.util.List;

public class BusinessClass {

	PersonDao dao;

	public BusinessClass() {
		super();
	}

	public BusinessClass(PersonDao dao) {
		super();
		this.dao = dao;
	}
	
	public void insertRow(){
		Person p1=new Person("navneet","pune",23);
		int n=dao.insertObj(p1);
		if(n > 0){
    		System.out.println("Record Inserted");
    	}
	}
	public void firstRecord(){
		dao.showRecord("navneet");
	}
	public void showAll(){
		List<Person> plist=dao.displayAll();
		for(Person p:plist)
		{
			System.out.println(p);
		}
	}
}
