package springEx;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
	public static void main(String[] args) {
	      ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
	      Message obj = (Message) context.getBean("msgBean");
	      System.out.println(obj.getMessage());
	    
	      obj.setMessage("hello");
	      System.out.println(obj.getMessage());
	      Message msg2=(Message) context.getBean("msgBean");
	      System.out.println(msg2.getMessage());
	      msg2.setMessage("bye");
	      System.out.println(obj.getMessage());
	      System.out.println(msg2.getMessage());
}
}