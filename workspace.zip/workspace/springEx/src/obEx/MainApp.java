package obEx;

import java.util.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("Beans3.xml");
		College c1=(College)context.getBean("colBean");
		List<Teacher> tlist=c1.getTob();
		List<Student> slist=c1.getSob();
		 System.out.println("college details");
		 System.out.println("college name : "+c1.getName());
		 System.out.println("reg no : "+c1.getRegno());
		 System.out.println("college addr : "+c1.getAddr());
		 System.out.println("college phn : "+c1.getPhn());
		 
		for(Student s1:slist)
{
		 System.out.println("student details");
		 System.out.println("student name : "+s1.getName());
		 System.out.println("student regno : "+s1.getRegno());
		 System.out.println("student addr : "+s1.getAddr());
		 System.out.println("student phn : "+s1.getPhn());
		 System.out.println("student age : "+s1.getAge());
}
		for(Teacher t1:tlist){
		 System.out.println("Teacher details");
		 System.out.println("Teacher name : "+t1.getName());
		 System.out.println("Teacher regno : "+t1.getRegno());
		 System.out.println("Teacher addr : "+t1.getAddr());
		 System.out.println("Teacher phn : "+t1.getPhn());
		 System.out.println("Teacher age : "+t1.getAge());
		 System.out.println("Teacher dept : "+t1.getDept());
	}
	}
}
