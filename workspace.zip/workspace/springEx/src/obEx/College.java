package obEx;

import java.util.*;

public class College {
	private String regno,name,addr,phn;
	private List<Teacher> tob;
	private List<Student> sob;
	
	public College(String regno, String name, String addr, String phn, List<Teacher> tob, List<Student> sob) {
		super();
		this.regno = regno;
		this.name = name;
		this.addr = addr;
		this.phn = phn;
		this.tob = tob;
		this.sob = sob;
	}
	public List<Teacher> getTob() {
		return tob;
	}
	public void setTob(List<Teacher> tob) {
		this.tob = tob;
	}
	public List<Student> getSob() {
		return sob;
	}
	public void setSob(List<Student> sob) {
		this.sob = sob;
	}
	public College(){}

	public String getRegno() {
		return regno;
	}
	public void setRegno(String regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getPhn() {
		return phn;
	}
	public void setPhn(String phn) {
		this.phn = phn;
	}
	
}
