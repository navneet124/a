package obEx;

public class Teacher {

	private String regno,name,addr,phn,dept;
	private int age;
	
	public Teacher(){}
	public Teacher(String regno, String name, String addr, String phn, String dept, int age) {
		super();
		this.regno = regno;
		this.name = name;
		this.addr = addr;
		this.phn = phn;
		this.dept = dept;
		this.age = age;
	}
	public String getRegno() {
		return regno;
	}
	public void setRegno(String regno) {
		this.regno = regno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getPhn() {
		return phn;
	}
	public void setPhn(String phn) {
		this.phn = phn;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
