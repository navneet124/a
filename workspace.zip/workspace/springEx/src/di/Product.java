package di;

public class Product {

	private String pCode,category;
	private int price;
	private Supplier sup;
	
	public Supplier getSup() {
		return sup;
	}
	public void setSup(Supplier sup) {
		this.sup = sup;
	}
	public Product(String pCode, String category, int price, Supplier sup) {
		super();
		this.pCode = pCode;
		this.category = category;
		this.price = price;
		this.sup=sup;
	}
	public String getpCode() {
		return pCode;
	}
	public void setpCode(String pCode) {
		this.pCode = pCode;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Product(){}
	
	public void init(){
		System.out.println("initialising spring bean");
	}
}
