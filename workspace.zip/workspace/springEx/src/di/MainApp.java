package di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ApplicationContext context = new ClassPathXmlApplicationContext("Beans1.xml");
		 Product p1 = (Product) context.getBean("pBean");
		 
		 System.out.println("Product Code : "+p1.getpCode());
		 System.out.println("Price : "+p1.getPrice());
		 System.out.println("Product Code : "+p1.getCategory());
		
		/* ProductType pt1=(ProductType)context.getBean("ptBean");
		 System.out.println("Product Type : "+pt1.getCategory());
		 System.out.println("Product Code : "+pt1.getpCode());
		 System.out.println("Product name : "+pt1.getName());
		 System.out.println("Price : "+pt1.getPrice());*/
		 
		 //Supplier s1=(Supplier) context.getBean("sup");
		 System.out.println("Supplier Details:");
		 System.out.println("supplier Name : "+p1.getSup().getSname());
		 System.out.println("supplier No : "+p1.getSup().getNumber());
		 /*System.out.println("supplier Name : "+s1.getSname());
		 System.out.println("supplier No : "+s1.getNumber());
		 System.out.println("supplier Addr : "+s1.getSadd());
		 */
	}

}
