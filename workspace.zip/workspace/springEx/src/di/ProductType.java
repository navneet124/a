package di;

public class ProductType {
private String name,pCode,category;
private int price;
private Supplier sup;

public ProductType(String name, String pCode, String category, int price, Supplier sup) {
	super();
	this.name = name;
	this.pCode = pCode;
	this.category = category;
	this.price = price;
	this.sup = sup;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public Supplier getSup() {
	return sup;
}

public void setSup(Supplier sup) {
	this.sup = sup;
}

public String getpCode() {
	return pCode;
}

public void setpCode(String pCode) {
	this.pCode = pCode;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public ProductType(){}

public void init(){
	System.out.println("initialising spring bean of product type");
}

}