package ex3;

public class Seq {
	
	private String prefix;
	private String suffix;
	private int initial;
	private int counter;
		
	public Seq() {
		super();
	}
	public Seq(String prefix, String suffix, int initial) {
		super();
		this.prefix = prefix;
		this.suffix = suffix;
		this.initial = initial;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public int getInitial() {
		return initial;
	}
	public void setInitial(int initial) {
		this.initial = initial;
	}
	
		public synchronized String getSeq(){
				StringBuilder sb=new StringBuilder();
				sb.append(prefix);
				sb.append(initial+counter++);
				sb.append(suffix);		
				return sb.toString();
	}
}
