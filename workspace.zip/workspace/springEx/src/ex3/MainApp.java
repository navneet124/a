package ex3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("Seqbeans.xml");
		Seq s=(Seq)context.getBean("seqbean");
		for(int i=0;i<5;i++)
		System.out.println(s.getSeq());
		
	}

}
