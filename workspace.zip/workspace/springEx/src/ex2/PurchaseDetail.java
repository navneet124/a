package ex2;

import org.springframework.beans.factory.annotation.Value;

public class PurchaseDetail {

	@Value("5002")
	private int itemCode;
	@Value("3")
	private int qty;
	@Value("3000")
	private int calcBill;
	
	@Override
	public String toString() {
		return "PurchaseDetail [itemCode=" + itemCode + ", qty=" + qty + ", calcBill=" + calcBill + "]";
	}
	public PurchaseDetail() {
		super();
	}
	public PurchaseDetail(int itemCode, int qty, int calcBill) {
		super();
		this.itemCode = itemCode;
		this.qty = qty;
		this.calcBill = calcBill;
	}
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public int getCalcBill() {
		return calcBill;
	}
	public void setCalcBill(int calcBill) {
		this.calcBill = calcBill;
	}
	
}
