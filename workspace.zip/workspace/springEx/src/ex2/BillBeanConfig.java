package ex2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class BillBeanConfig {

	@Bean
	@Scope("prototype")
	public Bill getBillBean()
	{
		return new Bill();
	}
}
