package ex2;

import org.springframework.beans.factory.annotation.*;

public class Purchase {

	@Value("Watch")
	private String itemName;
	@Value("3")
	private int qty;
	@Value("3000")
	private int billAmt;
	@Value("3000")
	private int totalAmt;
	
	public Purchase() {
		super();
	}
	public Purchase(String itemName, int qty, int billAmt, int totalAmt) {
		super();
		this.itemName = itemName;
		this.qty = qty;
		this.billAmt = billAmt;
		this.totalAmt = totalAmt;
	}
	@Override
	public String toString() {
		return "Purchase [itemName=" + itemName + ", qty=" + qty + ", billAmt=" + billAmt + ", totalAmt=" + totalAmt
				+ "]";
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public int getBillAmt() {
		return billAmt;
	}
	public void setBillAmt(int billAmt) {
		this.billAmt = billAmt;
	}
	public int getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(int totalAmt) {
		this.totalAmt = totalAmt;
	}
	
}
