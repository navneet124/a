package annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

public class Book {

	@Value("1234")
	private int bcode;
	@Value("Physics")
	private String bname;
	@Value("250.00")
	private double price;
	@Autowired
	private Publisher p;
	
	@Override
	public String toString() {
		return "Book [bcode=" + bcode + ", bname=" + bname + ", price=" + price + ", p=" + p + "]";
	}
	@Autowired(required=true)
	public Book(int bcode, String bname, double price, Publisher p) {
		super();
		this.bcode = bcode;
		this.bname = bname;
		this.price = price;
		this.p = p;
	}
	

	public void setP(Publisher p) {
		this.p = p;
	}
	public Publisher getP() {
		return p;
	}
	public Book() {
		super();
	}
	
	public int getBcode() {
		return bcode;
	}
	public void setBcode(int bcode) {
		this.bcode = bcode;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
}
