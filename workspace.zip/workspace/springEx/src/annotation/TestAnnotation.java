package annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestAnnotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new AnnotationConfigApplicationContext(BookBeanConfig.class,PublisherBeanConfig.class);
		
		Book b1=(Book)context.getBean(Book.class);
		
		//System.out.println(b1);
		
		System.out.println("Name :"+b1.getBname()+"\nPrice :"+b1.getPrice()+"\npublisher name :"+b1.getP().getPname());
		
		Book b2=(Book)context.getBean(Book.class);
		b2.setBname("Maths");
		System.out.println("Name :"+b2.getBname()+"\nPrice :"+b2.getPrice());
		
		
		System.out.println("Name :"+b1.getBname()+"\nPrice :"+b1.getPrice());
		
	}

}
