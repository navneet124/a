package com.Sequence.ques1;

public class Sequnce {
	String prefix;
	String initial;
	String suffix;
	public Sequnce() {
		super();
	}
	public Sequnce(String prefix, String initial, String suffix) {
		super();
		this.prefix = prefix;
		this.initial = initial;
		this.suffix = suffix;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getInitial() {
		return initial;
	}
	public void setInitial(String initial) {
		this.initial = initial;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String genrator(){
		String g = prefix+initial+suffix;
		return g;
	}
}
