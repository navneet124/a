package com.Sequence.ques1;

public interface SequneceBeanDao {

	public int insert(Sequnce s);

	}
