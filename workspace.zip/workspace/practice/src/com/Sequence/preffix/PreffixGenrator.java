package com.Sequence.preffix;

import org.springframework.beans.factory.annotation.Value;

public class PreffixGenrator {
	@Value("nav")
	String preffix;

	public PreffixGenrator() {
		super();
	}
	public PreffixGenrator(String preffix) {
		super();
		this.preffix = preffix;
	}

	public String getPreffix() {
		return preffix;
	}
	public void setPreffix(String preffix) {
		this.preffix = preffix;
	}
}
